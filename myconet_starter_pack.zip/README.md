# 🍄 MycoNet

Fungal-inspired traffic optimization using Physarum pathfinding.